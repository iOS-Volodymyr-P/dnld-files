package main

/*
#cgo CFLAGS: -x objective-c
#cgo LDFLAGS: -framework Foundation
#import <Foundation/Foundation.h>
#import <os/log.h>

static void log_info(const char* subsystem, const char* category, const char* message) {
    os_log_t log = os_log_create(subsystem, category);
    os_log_with_type(log, OS_LOG_TYPE_INFO, "%{public}s", message);
}

static void log_error(const char* subsystem, const char* category, const char* message) {
    os_log_t log = os_log_create(subsystem, category);
    os_log_with_type(log, OS_LOG_TYPE_ERROR, "%{public}s", message);
}

static void log_debug(const char* subsystem, const char* category, const char* message) {
    os_log_t log = os_log_create(subsystem, category);
    os_log_with_type(log, OS_LOG_TYPE_DEBUG, "%{public}s", message);
}

static void log_default(const char* subsystem, const char* category, const char* message) {
    os_log_t log = os_log_create(subsystem, category);
    os_log_with_type(log, OS_LOG_TYPE_DEFAULT, "%{public}s", message);
}
*/
import "C"

import (
    "bytes"
    "compress/gzip"
    "context"
    "fmt"
    "io"
    "net"
    "net/http"
    "strconv"
    "strings"
    "sync" 
    "time"
    "unsafe"
)

const (
    // Change these to match your app's bundle identifier
    logSubsystem = "com.pysarenkoDev.AdB360Test.AdB360TestTP"
    logCategory  = "network"
)

// OSLog wraps macOS os_log functionality
type OSLog struct {
    subsystem string
    category  string
}

// NewOSLog creates a new OS logger
func NewOSLog(subsystem, category string) *OSLog {
    return &OSLog{
        subsystem: subsystem,
        category:  category,
    }
}

func (l *OSLog) Info(format string, args ...interface{}) {
    msg := fmt.Sprintf(format, args...)
    cSubsystem := C.CString(l.subsystem)
    cCategory := C.CString(l.category)
    cMsg := C.CString(msg)
    defer C.free(unsafe.Pointer(cSubsystem))
    defer C.free(unsafe.Pointer(cCategory))
    defer C.free(unsafe.Pointer(cMsg))
    
    C.log_info(cSubsystem, cCategory, cMsg)
}

func (l *OSLog) Error(format string, args ...interface{}) {
    msg := fmt.Sprintf(format, args...)
    cSubsystem := C.CString(l.subsystem)
    cCategory := C.CString(l.category)
    cMsg := C.CString(msg)
    defer C.free(unsafe.Pointer(cSubsystem))
    defer C.free(unsafe.Pointer(cCategory))
    defer C.free(unsafe.Pointer(cMsg))
    
    C.log_error(cSubsystem, cCategory, cMsg)
}

func (l *OSLog) Debug(format string, args ...interface{}) {
    msg := fmt.Sprintf(format, args...)
    cSubsystem := C.CString(l.subsystem)
    cCategory := C.CString(l.category)
    cMsg := C.CString(msg)
    defer C.free(unsafe.Pointer(cSubsystem))
    defer C.free(unsafe.Pointer(cCategory))
    defer C.free(unsafe.Pointer(cMsg))
    
    C.log_debug(cSubsystem, cCategory, cMsg)
}

func (l *OSLog) Default(format string, args ...interface{}) {
    msg := fmt.Sprintf(format, args...)
    cSubsystem := C.CString(l.subsystem)
    cCategory := C.CString(l.category)
    cMsg := C.CString(msg)
    defer C.free(unsafe.Pointer(cSubsystem))
    defer C.free(unsafe.Pointer(cCategory))
    defer C.free(unsafe.Pointer(cMsg))
    
    C.log_default(cSubsystem, cCategory, cMsg)
}

var (
    redHeaderName  = "X-Red"
    redHeaderValue = "true"
    logger         = NewOSLog(logSubsystem, logCategory)
    proxyServer    *http.Server
    proxyMutex     sync.Mutex  // Add mutex for thread safety
    isRunning      bool        // Track if proxy is running
)

const injectedHTML = `<div style="width:100%;background:red;color:white;text-align:center;padding:10px;font-size:20px;z-index:9999;">🚀 Injected by Go Proxy MITM 🚀</div>`

func proxyHandler(w http.ResponseWriter, r *http.Request) {
    logger.Info("========== NEW REQUEST ==========")
    logger.Info(">>> Method: %s", r.Method)
    logger.Info(">>> URL: %s", r.URL.String())
    logger.Info(">>> URL.Host: %s", r.URL.Host)
    logger.Info(">>> URL.Scheme: %s", r.URL.Scheme)
    logger.Info(">>> URL.Path: %s", r.URL.Path)
    logger.Info(">>> Host header: %s", r.Host)
    logger.Info(">>> User-Agent: %s", r.Header.Get("User-Agent"))

    if r.Method == http.MethodConnect {
        handleConnect(w, r)
        return
    }

    // FIX: Handle non-proxy HTTP requests (direct connection format)
    if r.URL.Host == "" {
        host := r.Host
        if host == "" {
            http.Error(w, "Bad Request: missing host", http.StatusBadRequest)
            return
        }

        scheme := "http"
        if r.TLS != nil {
            scheme = "https"
        }

        r.URL.Scheme = scheme
        r.URL.Host = host
        logger.Debug(">>> Reconstructed URL: %s", r.URL.String())
    }

    logger.Info(">>> Received request: %s %s", r.Method, r.URL)

    outReq := r.Clone(r.Context())
    removeHopByHopHeaders(outReq.Header)

    // CRITICAL: Remove all caching to force fresh responses
    outReq.Header.Del("Accept-Encoding")
    outReq.Header.Del("If-Modified-Since")
    outReq.Header.Del("If-None-Match")
    outReq.Header.Del("If-Match")
    outReq.Header.Del("If-Unmodified-Since")
    outReq.Header.Del("If-Range")
    outReq.Header.Set("Cache-Control", "no-cache")
    outReq.Header.Set("Pragma", "no-cache")

    transport := http.DefaultTransport.(*http.Transport).Clone()
    transport.Proxy = nil

    logger.Debug(">>> Sending request to upstream: %s", outReq.URL.String())
    resp, err := transport.RoundTrip(outReq)
    if err != nil {
        logger.Error(">>> Upstream error: %v", err)
        http.Error(w, "Upstream error: "+err.Error(), http.StatusBadGateway)
        return
    }
    defer resp.Body.Close()
    logger.Debug(">>> Received response from upstream")

    removeHopByHopHeaders(resp.Header)

    // CRITICAL: Disable ALL caching in response (before processing body)
    resp.Header.Del("ETag")
    resp.Header.Del("Last-Modified")
    resp.Header.Set("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0, private")
    resp.Header.Set("Pragma", "no-cache")
    resp.Header.Set("Expires", "0")

    contentType := resp.Header.Get("Content-Type")
    logger.Info(">>> Response Status: %d", resp.StatusCode)
    logger.Info(">>> Response Content-Type: %s", contentType)
    
    isHtml := isHTML(contentType)
    if isHtml {
        resp.Header.Set(redHeaderName, redHeaderValue)
        logger.Info(">>> HTML detected, will inject red square")
    } else {
        logger.Info(">>> NOT HTML, skipping injection")
    }

    var body []byte
    var readErr error
    body, readErr = io.ReadAll(resp.Body)
    if readErr != nil {
        logger.Error(">>> Read upstream body error: %v", readErr)
        http.Error(w, "Read upstream body error: "+readErr.Error(), http.StatusBadGateway)
        return
    }
    
    logger.Debug(">>> Original body length: %d bytes", len(body))

    // Decompress if gzip
    encoding := strings.ToLower(strings.TrimSpace(resp.Header.Get("Content-Encoding")))
    logger.Debug(">>> Content-Encoding: '%s'", encoding)
    if encoding == "gzip" {
        logger.Info(">>> Decompressing gzipped content")
        body, err = ungzip(body)
        if err != nil {
            logger.Error(">>> Ungzip error: %v", err)
            http.Error(w, "Ungzip error: "+err.Error(), http.StatusBadGateway)
            return
        }
        resp.Header.Del("Content-Encoding")
        logger.Debug(">>> Decompressed body length: %d bytes", len(body))
    }

    if isHtml {
        logger.Info(">>> Starting HTML injection")
        originalLen := len(body)
        body = injectRedSquare(body)
        logger.Info(">>> Injected red square - body length: %d -> %d bytes", originalLen, len(body))
    } else {
        logger.Debug(">>> Skipping injection - not HTML")
    }

    // Always update Content-Length after potential modification
    resp.Header.Set("Content-Length", strconv.Itoa(len(body)))

    // Write headers + status
    copyHeaders(w.Header(), resp.Header)
    
    // CRITICAL: Additional cache prevention
    w.Header().Set("Vary", "*")
    
    w.WriteHeader(resp.StatusCode)

    bytesWritten, writeErr := w.Write(body)
    if writeErr != nil {
        logger.Error(">>> Error writing response to client: %v", writeErr)
    } else {
        logger.Info(">>> Response sent successfully: %d bytes, status %d", bytesWritten, resp.StatusCode)
    }
}

func injectRedSquare(body []byte) []byte {
    lower := bytes.ToLower(body)
    
    // Try to inject after <body> tag first
    bodyTag := []byte("<body")
    idx := bytes.Index(lower, bodyTag)
    
    if idx >= 0 {
        // Find the end of the opening <body> tag (could be <body> or <body attr="value">)
        closeIdx := bytes.IndexByte(lower[idx:], '>')
        if closeIdx >= 0 {
            insertPos := idx + closeIdx + 1
            logger.Debug(">>> Found <body> tag, injecting after it at position %d", insertPos)
            
            out := make([]byte, 0, len(body)+len(injectedHTML))
            out = append(out, body[:insertPos]...)
            out = append(out, []byte(injectedHTML)...)
            out = append(out, body[insertPos:]...)
            return out
        }
    }
    
    // Fallback: try after <head> closing tag
    headTag := []byte("</head>")
    idx = bytes.Index(lower, headTag)
    if idx >= 0 {
        insertPos := idx + len(headTag)
        logger.Debug(">>> Found </head> tag, injecting after it at position %d", insertPos)
        
        out := make([]byte, 0, len(body)+len(injectedHTML))
        out = append(out, body[:insertPos]...)
        out = append(out, []byte(injectedHTML)...)
        out = append(out, body[insertPos:]...)
        return out
    }

    // Final fallback: prepend at the very beginning
    logger.Debug(">>> No <body> or </head> tag found, prepending at start")
    out := make([]byte, 0, len(body)+len(injectedHTML))
    out = append(out, []byte(injectedHTML)...)
    out = append(out, body...)
    return out
}

func ungzip(b []byte) ([]byte, error) {
    r, err := gzip.NewReader(bytes.NewReader(b))
    if err != nil {
        return nil, err
    }
    defer r.Close()
    return io.ReadAll(r)
}

func isHTML(contentType string) bool {
    ct := strings.ToLower(contentType)
    return strings.HasPrefix(ct, "text/html")
}

func copyHeaders(dst, src http.Header) {
    for k, vv := range src {
        for _, v := range vv {
            dst.Add(k, v)
        }
    }
}

func removeHopByHopHeaders(h http.Header) {
    if c := h.Get("Connection"); c != "" {
        for _, f := range strings.Split(c, ",") {
            if f = strings.TrimSpace(f); f != "" {
                h.Del(f)
            }
        }
    }
    for _, k := range []string{
        "Connection",
        "Proxy-Connection",
        "Keep-Alive",
        "Proxy-Authenticate",
        "Proxy-Authorization",
        "Te",
        "Trailer",
        "Transfer-Encoding",
        "Upgrade",
    } {
        h.Del(k)
    }
}

func handleConnect(w http.ResponseWriter, r *http.Request) {
    logger.Info(">>> CONNECT request to: %s", r.Host)
    logger.Debug(">>> CONNECT User-Agent: %s", r.Header.Get("User-Agent"))
    
    dstConn, err := net.DialTimeout("tcp", r.Host, 10*time.Second)
    if err != nil {
        logger.Error("Dial error: %v", err)
        http.Error(w, "Dial error: "+err.Error(), http.StatusServiceUnavailable)
        return
    }

    hj, ok := w.(http.Hijacker)
    if !ok {
        logger.Error("Hijacking not supported")
        http.Error(w, "Hijacking not supported", http.StatusInternalServerError)
        _ = dstConn.Close()
        return
    }

    clientConn, _, err := hj.Hijack()
    if err != nil {
        logger.Error("Hijack error: %v", err)
        http.Error(w, "Hijack error: "+err.Error(), http.StatusServiceUnavailable)
        _ = dstConn.Close()
        return
    }

    _, _ = clientConn.Write([]byte("HTTP/1.1 200 Connection Established\r\n\r\n"))
    logger.Info(">>> CONNECT tunnel established to %s", r.Host)

    ctx, cancel := context.WithCancel(context.Background())
    go pipe(ctx, cancel, dstConn, clientConn)
    go pipe(ctx, cancel, clientConn, dstConn)
}

func pipe(ctx context.Context, cancel context.CancelFunc, dst io.WriteCloser, src io.ReadCloser) {
    defer cancel()
    _, _ = io.Copy(dst, src)
    _ = dst.Close()
    _ = src.Close()
    <-ctx.Done()
}

//export StartProxy
func StartProxy() {
    proxyMutex.Lock()
    defer proxyMutex.Unlock()
    
    if isRunning {
        logger.Info("Proxy already running, skipping start")
        return
    }
    
    logger.Info("StartProxy called!")
    
    go func() {
        addr := "127.0.0.1:4003"
        
        proxyMutex.Lock()
        proxyServer = &http.Server{
            Addr:    addr,
            Handler: http.HandlerFunc(proxyHandler),
        }
        isRunning = true
        proxyMutex.Unlock()
        
        logger.Info("Proxy listening on http://%s", addr)
        
        if err := proxyServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
            logger.Error("Proxy error: %v", err)
            proxyMutex.Lock()
            isRunning = false
            proxyMutex.Unlock()
        }
    }()
    
    // Give the server time to start
    time.Sleep(200 * time.Millisecond)
    logger.Info("StartProxy initialization complete")
}

//export StopProxy
func StopProxy() {
    proxyMutex.Lock()
    
    if proxyServer == nil || !isRunning {
        logger.Info("No proxy server to stop (already stopped)")
        proxyMutex.Unlock()
        return
    }
    
    logger.Info("Stopping proxy server...")
    srv := proxyServer
    proxyMutex.Unlock()
    
    // Create a context with timeout for graceful shutdown
    ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
    defer cancel()
    
    if err := srv.Shutdown(ctx); err != nil {
        logger.Error("Error during proxy shutdown: %v", err)
        // Force close if graceful shutdown fails
        if closeErr := srv.Close(); closeErr != nil {
            logger.Error("Error during proxy force close: %v", closeErr)
        }
    } else {
        logger.Info("Proxy server stopped successfully")
    }
    
    proxyMutex.Lock()
    proxyServer = nil
    isRunning = false
    proxyMutex.Unlock()
}

func main() {}
