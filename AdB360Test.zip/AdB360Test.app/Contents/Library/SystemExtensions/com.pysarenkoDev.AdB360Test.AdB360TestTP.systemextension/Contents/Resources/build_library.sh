#!/bin/bash
set -e

MIN_VER="14.0"
LIB_NAME="libhttpproxy"
BUILD_DIR="build"

rm -rf $BUILD_DIR
mkdir -p $BUILD_DIR

cd GoProxyWithServer

echo "🧱 Building Intel..."
GOOS=darwin \
GOARCH=amd64 \
CGO_ENABLED=1 \
CGO_CFLAGS="-mmacosx-version-min=$MIN_VER" \
CGO_LDFLAGS="-mmacosx-version-min=$MIN_VER" \
go build -buildmode=c-archive -o ../$BUILD_DIR/${LIB_NAME}_amd64.a

echo "📄 Copying header..."
cp ../$BUILD_DIR/${LIB_NAME}_amd64.h ../$BUILD_DIR/${LIB_NAME}.h

echo "🧱 Building Apple Silicon..."
GOOS=darwin \
GOARCH=arm64 \
CGO_ENABLED=1 \
CGO_CFLAGS="-mmacosx-version-min=$MIN_VER" \
CGO_LDFLAGS="-mmacosx-version-min=$MIN_VER" \
go build -buildmode=c-archive -o ../$BUILD_DIR/${LIB_NAME}_arm64.a

cd ..

echo "🧬 Creating universal lib..."
lipo -create \
$BUILD_DIR/${LIB_NAME}_amd64.a \
$BUILD_DIR/${LIB_NAME}_arm64.a \
-output $BUILD_DIR/${LIB_NAME}.a

rm $BUILD_DIR/${LIB_NAME}_amd64.a
rm $BUILD_DIR/${LIB_NAME}_arm64.a
rm $BUILD_DIR/${LIB_NAME}_amd64.h
rm $BUILD_DIR/${LIB_NAME}_arm64.h

echo "✅ Done:"
echo "   $BUILD_DIR/${LIB_NAME}.a"
echo "   $BUILD_DIR/${LIB_NAME}.h"

lipo -info $BUILD_DIR/${LIB_NAME}.a
